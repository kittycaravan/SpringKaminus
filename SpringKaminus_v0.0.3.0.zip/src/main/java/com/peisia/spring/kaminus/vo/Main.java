package com.peisia.spring.kaminus.vo;

public class Main {
//	temp: 276.81,
//	feels_like: 274.64,
//	temp_min: 274.84,
//	temp_max: 276.81,
//	pressure: 1025,
//	humidity: 41,
//	sea_level: 1025,
//	grnd_level: 1018
	public String temp;
	public String feels_like;
	public String temp_min;
	public String temp_max;
	public String pressure;
	public String humidity;
	public String sea_level;
	public String grnd_level;
}

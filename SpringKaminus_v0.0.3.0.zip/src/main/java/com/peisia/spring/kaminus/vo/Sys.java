package com.peisia.spring.kaminus.vo;

public class Sys {
//	type: 1,
//	id: 5509,
//	country: "KR",
//	sunrise: 1675463631,
//	sunset: 1675501079
	public String type;
	public String id;
	public String country;
	public String sunrise;
	public String sunset;
}

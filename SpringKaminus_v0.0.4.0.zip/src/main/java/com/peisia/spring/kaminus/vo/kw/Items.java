
package com.peisia.spring.kaminus.vo.kw;

import java.util.List;

public class Items {
    public List<Item> item;
}

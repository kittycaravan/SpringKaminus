package com.peisia.spring.kaminus.vo.kw;

public class Response {
    public Header header;
    public Body body;
}
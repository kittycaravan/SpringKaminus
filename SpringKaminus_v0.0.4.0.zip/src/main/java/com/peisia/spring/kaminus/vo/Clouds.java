package com.peisia.spring.kaminus.vo;

public class Clouds {
//	all: 0
	public String all;
}

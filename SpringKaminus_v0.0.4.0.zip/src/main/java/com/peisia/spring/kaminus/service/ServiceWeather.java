package com.peisia.spring.kaminus.service;

import com.peisia.spring.kaminus.vo.VoWeather;

public interface ServiceWeather {
	public VoWeather getYesterdayWeather();
}
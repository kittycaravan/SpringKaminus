package com.peisia.spring.kaminus.vo;

import java.util.List;

public class VoWeather{
    public Coord coord;
    public List<Weather> weather;
    public String base;	
    public Main main;
    public String visibility;	
    public Wind wind;
    public Clouds clouds;
    public String dt;	
    public Sys sys;
    public String timezone;	
    public String id;	
    public String name;	
    public String cod;
	@Override
	public String toString() {
		return "VoWeather [coord=" + coord + ", weather=" + weather + ", base=" + base + ", main=" + main
				+ ", visibility=" + visibility + ", wind=" + wind + ", clouds=" + clouds + ", dt=" + dt + ", sys=" + sys
				+ ", timezone=" + timezone + ", id=" + id + ", name=" + name + ", cod=" + cod + "]";
	}
}
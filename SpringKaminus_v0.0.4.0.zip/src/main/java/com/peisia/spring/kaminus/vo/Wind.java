package com.peisia.spring.kaminus.vo;

public class Wind {
//	speed: 2.31,
//	deg: 261,
//	gust: 4.57
	public String speed;
	public String deg;
	public String gust;
}

package com.peisia.spring.kaminus.vo;

public class Weather {
//	id: 800,
//	main: "Clear",
//	description: "clear sky",
//	icon: "01n"
	public String id;
	public String main;
	public String description;
	public String icon;
}

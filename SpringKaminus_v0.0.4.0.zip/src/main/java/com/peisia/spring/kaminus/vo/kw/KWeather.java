
package com.peisia.spring.kaminus.vo.kw;

public class KWeather {

    public Response response;

}

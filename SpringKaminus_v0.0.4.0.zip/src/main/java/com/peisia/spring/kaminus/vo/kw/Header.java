
package com.peisia.spring.kaminus.vo.kw;

public class Header {

    public String resultCode;
    public String resultMsg;

}

package com.peisia.spring.kaminus.service;

public interface ServiceKoreaWeather {
	public void weather();
}
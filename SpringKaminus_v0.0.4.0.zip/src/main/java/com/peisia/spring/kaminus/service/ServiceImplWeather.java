package com.peisia.spring.kaminus.service;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.peisia.spring.kaminus.vo.VoWeather;

import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class ServiceImplWeather implements ServiceWeather {

	//// 성공한거 - 외국 api ////
	private static final String API_KEY = "91c6bab000a089b3816da2bd6f86d094";
	private static final String API_URL = "http://api.openweathermap.org/data/2.5/weather?q={city}&appid=" + API_KEY;

	//// 성공한거 - 외국 api ////
	@Override
	public VoWeather getYesterdayWeather() {
		String city = "SEOUL";
		RestTemplate restTemplate = new RestTemplate();
//		String s = restTemplate.getForObject(API_URL, String.class, city);
		VoWeather voWeather = restTemplate.getForObject(API_URL, VoWeather.class, city); //
		// return weather;
		return voWeather;
	}
}
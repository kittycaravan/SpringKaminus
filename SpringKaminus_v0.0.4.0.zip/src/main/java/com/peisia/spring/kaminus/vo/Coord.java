package com.peisia.spring.kaminus.vo;

public class Coord {
//	lon: 126.9778,
//	lat: 37.5683
	public String lon;
	public String lat;
}

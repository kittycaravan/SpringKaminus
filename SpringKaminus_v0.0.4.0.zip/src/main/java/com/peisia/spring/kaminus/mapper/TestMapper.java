package com.peisia.spring.kaminus.mapper;

import com.peisia.spring.kaminus.dto.TestDto;

public interface TestMapper {
	public TestDto getData1();
	public TestDto getData2();
	public TestDto getData3();
	public TestDto getData4();
}

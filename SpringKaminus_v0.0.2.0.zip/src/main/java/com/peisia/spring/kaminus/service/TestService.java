package com.peisia.spring.kaminus.service;

public interface TestService {
	public String getOne();
	public String getTwo();
}
